﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogMyInput
{
	class Program
	{
		internal static readonly log4net.ILog log = log4net.LogManager.GetLogger
	(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

		static void Main(string[] args)
		{
			Counter counter = new Counter();
			Console.WriteLine("Hello! Welcome to MatrixLogger - 9000!");

			while (true)
			{
				Console.WriteLine("------------------------------------------------------------------");
				Console.WriteLine();
				Console.WriteLine("Please enter a positive integer (any number between 1 and 2,147,483,647)");
				Console.WriteLine("Or press X to exit.");
				var input = Console.ReadLine();
				if (input.ToLower() == "x")
				{
					Environment.Exit(0);
				}

				int.TryParse(input, out int userInput);
				double elapsedLoopTime = counter.CountIterations(userInput);

				if (elapsedLoopTime < 0)
				{
					Console.WriteLine("Something went wrong! Please insert a full number between 1 and 2,147,483,647 \n(Only positive integers are allowed!)");
				}
				else
				{
					log.Info($"input: {userInput} - Time: {elapsedLoopTime} ms");
					Console.WriteLine("The following entry has been logged: ");
					Console.WriteLine($"input: {userInput} - Time: {elapsedLoopTime} ms");
				}
			}
		}
	}
}
