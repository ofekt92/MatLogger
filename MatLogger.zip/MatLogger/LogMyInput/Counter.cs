﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogMyInput
{
	/// <summary>
	/// Counter for the user input.
	/// </summary>
	/// 
	internal class Counter
	{
		/// <summary>
		///     Fields.
		/// </summary>
		 Stopwatch _sWatch;

		/// <summary>
		///   	Constructor
		/// </summary>
		public Counter()
		{
			_sWatch = new Stopwatch();
		}
		/// <summary>
		///   Returns the time it took for a loop to iterate through the user <paramref name="input"/> in milliseconds.
		/// </summary>
		/// <param name="input"></param>
		/// <returns></returns>
		public double CountIterations(int input)
		{
			try
			{
				if (
					input <= 0
					|| _sWatch.IsRunning) // <--- This is extra precaution, might never happen because of the finally at the end of func.
					return -1;
				else
				{
					_sWatch.Start();
					for (int i = 0; i < input; i++) { } // <--- No need for code here, anything would be unnecessary.

					_sWatch.Stop();
					return Math.Round(_sWatch.Elapsed.TotalMilliseconds, 1);
				}
			}
			catch (Exception e)
			{
				Program.log.Debug(e); // <--- Log exception to file.
				return -1;
			}
			finally
			{
				_sWatch.Reset(); // <--- Resets the stopwatch, so as to not get false values in the next try if an exception was made on this try.
			}
		}
	}
}
